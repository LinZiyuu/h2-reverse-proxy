
def self.include (*modules)
  self.class.include(*modules)
end

def self.private(*methods)
end
def self.protected(*methods)
end
def self.public(*methods)
end
